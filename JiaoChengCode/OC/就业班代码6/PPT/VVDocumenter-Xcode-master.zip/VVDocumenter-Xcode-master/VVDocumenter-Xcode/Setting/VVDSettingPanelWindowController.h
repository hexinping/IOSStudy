//
//  VVDSettingPanelWindowController.h
//  VVDocumenter-Xcode
//
//  Created by 王 巍 on 13-8-3.
//  Copyright (c) 2013年 OneV's Den. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface VVDSettingPanelWindowController : NSWindowController

@end
